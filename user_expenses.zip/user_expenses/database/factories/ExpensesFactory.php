<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Expenses;
use Faker\Generator as Faker;

$factory->define(Expenses::class, function (Faker $faker) {
    return [
        //
    ];
});
