<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- START MAIN CONTENT -->
    <section id="main-content">

      <section class="wrapper">
      	<h3><i class="fa fa-angle-right"></i> Expenses List</h3>
				<div class="row">
				
				</div><!-- row -->

              <div class="row mt">
                  <div class="col-md-12">
                      <div class="content-panel">
                          <table class="table table-striped table-advance table-hover">
                          <?php if(session()->get('success')): ?>
                            <div class="alert alert-success">
                              <?php echo e(session()->get('success')); ?>  
                            </div><br />
                          <?php endif; ?>
	                  	  	  <h4><i class="fa fa-angle-right"></i> Expenses List</h4>
	                  	  	  <hr>
                              <thead>
                              <tr>
                                  <th>ID</th>
                                  <th>Amount</th>
                                  <th>Category</th>
                                  <th></th>
                              </tr>
                              </thead>
                              <tbody>
                              <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($expense->expense_id); ?></td>
                                    <td><?php echo e($expense->amount); ?></td>
                                    <td><?php echo e($expense->category_id); ?></td>
                                    <td>
                                      <a href="<?php echo e(route('expenses.edit',$expense->expense_id)); ?>" class="btn btn-primary btn-xs" style="margin-right:2px;"><i class="fa fa-pencil"></i></a>
                                      <form action="<?php echo e(route('expenses.destroy', $expense->expense_id)); ?>" method="post" style="display:inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-xs" type="submit"><i class="fa fa-trash-o "></i></button>
                                      </form>
                                    </td>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                          </table>
                      </div><!-- /content-panel -->
                  </div><!-- /col-md-12 -->
              </div><!-- /row -->

		</section><!--/wrapper -->

  </section><!-- /MAIN CONTENT -->

<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php /**PATH F:\peekinternational\htdocs\user_expenses\resources\views/expenses/index.blade.php ENDPATH**/ ?>