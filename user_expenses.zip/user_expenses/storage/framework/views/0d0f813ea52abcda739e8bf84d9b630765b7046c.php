<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--main content start-->
  <section id="main-content">
    <section class="wrapper">
      	<h3><i class="fa fa-angle-right"></i> Categories List</h3>
  	<div class="row">
  	
  	</div><!-- row -->

          <div class="row mt">
              <div class="col-md-12">
              
                <div class="content-panel">
                    <table class="table table-striped table-advance table-hover">
                    <?php if(session()->get('success')): ?>
                    <div class="alert alert-success">
                      <?php echo e(session()->get('success')); ?>  
                    </div><br />
                  <?php endif; ?>
            	  	  <h4><i class="fa fa-angle-right"></i> Categories List</h4>
            	  	  <hr>
                      <thead>
                      <tr>
                          <th>ID</th>
                          <th>Category Name</th>
                          <th></th>
                      </tr>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($category->id); ?></td>
                            <td><?php echo e($category->category_name); ?></td>
                            <td>
                              <a href="<?php echo e(route('category.edit',$category->id)); ?>" class="btn btn-primary btn-xs" style="margin-right:2px;"><i class="fa fa-pencil"></i></a>
                              <form action="<?php echo e(route('category.destroy', $category->id)); ?>" method="post" style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-xs" type="submit"><i class="fa fa-trash-o "></i></button>
                              </form>
                            </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div><!-- /content-panel -->
            </div><!-- /col-md-12 -->
        </div><!-- /row -->

		</section><!--/wrapper -->

  </section><!-- /MAIN CONTENT -->

<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php /**PATH F:\peekinternational\htdocs\user_expenses\resources\views/category/index.blade.php ENDPATH**/ ?>