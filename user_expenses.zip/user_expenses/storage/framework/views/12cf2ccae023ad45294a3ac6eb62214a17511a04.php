<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
        	<h3><i class="fa fa-angle-right"></i> Expenses Form</h3>
        	
        	<!-- BASIC FORM ELELEMNTS -->
        	<div class="row mt">
        		<div class="col-lg-12">
                <div class="form-panel">
                	  <h4 class="mb"><i class="fa fa-angle-right"></i> Expenses Form</h4>
                    <?php if($errors->any()): ?>
                      <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                      </div><br />
                    <?php endif; ?>
                    <form class="form-horizontal style-form" method="post" action="<?php echo e(route('expenses.store')); ?>">
                        <div class="form-group">
                            <label class="col-sm-2 col-sm-2 control-label">Expense Amount</label>
                            <div class="col-sm-10">
                                <?php echo csrf_field(); ?>
                                <input type="text" class="form-control" name="amount">
                            </div>
                        </div> 

                        <div class="form-group">
                            <label class="col-sm-2 col-sm-2 control-label">Expense Date</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control date-picker" name="date"  autocomplete="off">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-2 col-sm-2 control-label">Category</label>
                            <div class="col-sm-10">
                              <select class="form-control" name="category_id">
                                <?php $__currentLoopData = $categories_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                            </div>
                        </div>
                        
                        <div class="text-right">
                          <button type="submit" class="btn btn-primary">Create Expense</button>
                        </div>
                    </form>
                </div>
        		</div><!-- col-lg-12-->      	
        	</div><!-- /row -->
        	
	    </section><!--/wrapper -->

    </section><!-- /MAIN CONTENT -->

    <!--main content end-->
    

<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH F:\peekinternational\htdocs\user_expenses\resources\views/expenses/create.blade.php ENDPATH**/ ?>