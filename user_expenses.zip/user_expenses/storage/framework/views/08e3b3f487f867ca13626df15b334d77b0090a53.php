<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper site-min-height">
          <h3><i class="fa fa-angle-right"></i> Dashboard</h3>
          <div class="row mt">
              <div class="col-lg-12">
                  <select class="form-control" name="category_id" id="category">
                    <?php $__currentLoopData = $categories_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>
          </div>
          <canvas id="myChart"></canvas>
      </section><!--/wrapper -->
    </section><!-- /MAIN CONTENT -->

    <!--main content end-->

  <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH F:\peekinternational\htdocs\user_expenses\resources\views/home.blade.php ENDPATH**/ ?>